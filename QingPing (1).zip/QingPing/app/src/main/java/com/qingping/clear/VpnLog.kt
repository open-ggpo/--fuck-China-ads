package com.qingping.clear

import java.util.ArrayDeque

/** 最近的 DNS 查询（仅保存在内存里，进程结束即清空），用来在界面上挑选要屏蔽/放行的域名 */
object VpnLog {
    data class Entry(val time: Long, val pkg: String?, val domain: String, val blocked: Boolean)

    private val buf = ArrayDeque<Entry>()

    @Synchronized
    fun add(e: Entry) {
        buf.addFirst(e)
        while (buf.size > 500) buf.removeLast()
    }

    @Synchronized
    fun snapshot(): List<Entry> = ArrayList(buf)
}
