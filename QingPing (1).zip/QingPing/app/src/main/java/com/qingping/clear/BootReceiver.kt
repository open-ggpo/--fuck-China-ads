package com.qingping.clear

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat

/**
 * 开机/升级后：
 * - 无障碍服务本身由系统在开机时自动绑定，不依赖这个接收器；
 * - 这里负责拉起前台服务，并在已 adb 授权且用户开启“自动重新开启”时恢复无障碍开关；
 * - 如果用户之前开着 DNS 过滤，并且 VPN 授权仍有效，就重新启动 VPN。
 *   更稳的做法是在系统「VPN 设置」里把清屏设为“始终开启的 VPN”（不要勾“阻止没有 VPN 的连接”）。
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                val prefs = Prefs(context)
                if (prefs.autoRevive) AccessibilityGuard.tryReEnable(context)
                if (prefs.keepAlive) {
                    try {
                        ContextCompat.startForegroundService(
                            context, Intent(context, KeepAliveService::class.java)
                        )
                    } catch (e: Exception) {
                    }
                }
                if (prefs.vpnEnabled && VpnService.prepare(context) == null) {
                    try {
                        context.startService(Intent(context, QpVpnService::class.java))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}
