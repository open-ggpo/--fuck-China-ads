package com.qingping.clear

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var db: StatsDb
    private lateinit var prefs: Prefs
    private lateinit var tvStatus: TextView
    private lateinit var tvSummary: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var swVpn: SwitchCompat
    private var uiSync = false
    private var vpnRequestedAt = 0L

    private val adapter = StatAdapter()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000)
        }
    }

    private val vpnConsent =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) startVpn() else setVpnSwitch(false)
        }

    private val pickList =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importBlocklist(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = StatsDb.get(this)
        prefs = Prefs(this)
        Thread { Blocklist.reload(applicationContext) }.start()

        val lv = findViewById<ListView>(R.id.lvStats)
        val header = layoutInflater.inflate(R.layout.header_main, lv, false)
        lv.addHeaderView(header, null, false)
        lv.adapter = adapter
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            val s = lv.getItemAtPosition(pos) as? AppStat
            if (s != null) confirmExclude(s)
            s != null
        }

        tvStatus = header.findViewById(R.id.tvStatus)
        tvSummary = header.findViewById(R.id.tvSummary)
        tvEmpty = header.findViewById(R.id.tvEmpty)
        swVpn = header.findViewById(R.id.swVpn)

        header.findViewById<View>(R.id.btnAccessibility).setOnClickListener { showAccessibilityGuide() }
        header.findViewById<View>(R.id.btnKeepAlive).setOnClickListener { showKeepAliveMenu() }
        header.findViewById<View>(R.id.btnDomains).setOnClickListener { showDomainMenu() }
        header.findViewById<View>(R.id.btnClear).setOnClickListener { confirmClear() }

        bindSwitch(header, R.id.swRedirect, prefs.redirectBack) { prefs.redirectBack = it }
        bindSwitch(header, R.id.swAggressive, prefs.aggressive) { prefs.aggressive = it }
        bindSwitch(header, R.id.swKeepAlive, prefs.keepAlive) { on ->
            prefs.keepAlive = on
            val i = Intent(this, KeepAliveService::class.java)
            if (on) ContextCompat.startForegroundService(this, i) else stopService(i)
        }
        bindSwitch(header, R.id.swRevive, prefs.autoRevive) { on ->
            if (on && !AccessibilityGuard.canWriteSecure(this)) {
                prefs.autoRevive = false
                header.findViewById<SwitchCompat>(R.id.swRevive).isChecked = false
                AlertDialog.Builder(this)
                    .setTitle(R.string.adb_title)
                    .setMessage(R.string.adb_message)
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            } else {
                prefs.autoRevive = on
            }
        }

        swVpn.isChecked = QpVpnService.running
        swVpn.setOnCheckedChangeListener { _, on ->
            if (uiSync) return@setOnCheckedChangeListener
            if (on) {
                vpnRequestedAt = SystemClock.elapsedRealtime()
                val consent = VpnService.prepare(this)
                if (consent != null) vpnConsent.launch(consent) else startVpn()
            } else {
                stopVpn()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (prefs.keepAlive) {
            ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun bindSwitch(root: View, id: Int, initial: Boolean, onChange: (Boolean) -> Unit) {
        val sw = root.findViewById<SwitchCompat>(id)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun setVpnSwitch(on: Boolean) {
        uiSync = true
        swVpn.isChecked = on
        uiSync = false
    }

    private fun startVpn() {
        prefs.vpnEnabled = true
        vpnRequestedAt = SystemClock.elapsedRealtime()
        startService(Intent(this, QpVpnService::class.java))
        setVpnSwitch(true)
    }

    private fun stopVpn() {
        prefs.vpnEnabled = false
        stopService(Intent(this, QpVpnService::class.java))
    }

    private fun refresh() {
        val vpnOn = QpVpnService.running
        val a11y = getString(
            when {
                SkipAccessibilityService.connected -> R.string.status_running
                AccessibilityGuard.isEnabled(this) -> R.string.status_enabled_not_connected
                else -> R.string.status_off
            }
        )
        val vpn = getString(if (vpnOn) R.string.status_vpn_on else R.string.status_vpn_off)
        tvStatus.text = "$a11y\n$vpn"

        // 用户在系统里关掉了 VPN 等情况：让开关跟实际状态一致（刚点开的 3 秒内不同步，避免和启动过程打架）
        if (swVpn.isChecked != vpnOn && SystemClock.elapsedRealtime() - vpnRequestedAt > 3000) {
            setVpnSwitch(vpnOn)
        }

        val data = db.queryAll()
        adapter.data = data
        adapter.notifyDataSetChanged()
        tvEmpty.visibility = if (data.isEmpty()) View.VISIBLE else View.GONE
        val skip = data.sumOf { it.skip }
        val back = data.sumOf { it.back }
        val dns = data.sumOf { it.dns }
        val today = data.sumOf { it.today }
        tvSummary.text = getString(R.string.summary, skip + back + dns, today, skip, back, dns)
    }

    // ---------------- 对话框 ----------------

    private fun showAccessibilityGuide() {
        AlertDialog.Builder(this)
            .setTitle(R.string.guide_title)
            .setMessage(R.string.guide_message)
            .setPositiveButton(R.string.open_accessibility) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton(R.string.open_app_info) { _, _ -> KeepAliveSettings.openAppInfo(this) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showKeepAliveMenu() {
        val items = arrayOf(
            "忽略电池优化",
            "自启动 / 后台运行（厂商页面）",
            "应用详情页（锁定后台等）",
            "系统 VPN 设置（可设为“始终开启”）"
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_keepalive)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> KeepAliveSettings.requestIgnoreBattery(this)
                    1 -> KeepAliveSettings.openAutoStart(this)
                    2 -> KeepAliveSettings.openAppInfo(this)
                    else -> try {
                        startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                    } catch (e: Exception) {
                        Toast.makeText(this, "请在系统设置 → 网络 → VPN 中查找", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .show()
    }

    private fun showDomainMenu() {
        val items = arrayOf(
            "导入 hosts / 域名列表文件",
            "最近的 DNS 查询（点选屏蔽 / 放行）",
            "清空自定义屏蔽与放行"
        )
        AlertDialog.Builder(this)
            .setTitle(Blocklist.describe())
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pickList.launch(arrayOf("*/*"))
                    1 -> showRecentQueries()
                    else -> Thread {
                        Blocklist.clearCustom(applicationContext)
                        runOnUiThread { Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show() }
                    }.start()
                }
            }
            .show()
    }

    private fun importBlocklist(uri: Uri) {
        Toast.makeText(this, "正在导入…", Toast.LENGTH_SHORT).show()
        Thread {
            val n = try {
                Blocklist.importFrom(applicationContext, uri)
            } catch (e: Exception) {
                -1
            }
            runOnUiThread {
                val msg = if (n >= 0) "导入完成，新增 $n 个域名" else "导入失败，请确认是文本文件"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun showRecentQueries() {
        val entries = VpnLog.snapshot().distinctBy { it.domain }.take(60)
        if (entries.isEmpty()) {
            Toast.makeText(this, "还没有记录：先开启 DNS 过滤，用一会儿其他 App", Toast.LENGTH_LONG).show()
            return
        }
        val items = entries.map { e ->
            val app = e.pkg?.let { "  ·  " + loadLabelIcon(it).first } ?: ""
            (if (e.blocked) "🚫 " else "　 ") + e.domain + app
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("最近的 DNS 查询（🚫 = 已屏蔽）")
            .setItems(items) { _, i -> toggleDomain(entries[i]) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun toggleDomain(e: VpnLog.Entry) {
        val blocked = e.blocked
        AlertDialog.Builder(this)
            .setTitle(if (blocked) "放行这个域名？" else "屏蔽这个域名？")
            .setMessage(e.domain + if (blocked) "" else "\n（含其所有子域名）")
            .setPositiveButton(android.R.string.ok) { _, _ ->
                Thread {
                    if (blocked) Blocklist.allow(applicationContext, e.domain)
                    else Blocklist.block(applicationContext, e.domain)
                }.start()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmExclude(s: AppStat) {
        val excluded = prefs.isExcluded(s.pkg)
        AlertDialog.Builder(this)
            .setTitle(if (excluded) "恢复处理此 App？" else "不再处理此 App？")
            .setMessage(s.pkg)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.setExcluded(s.pkg, !excluded)
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("清空所有统计？")
            .setPositiveButton(android.R.string.ok) { _, _ ->
                db.clear()
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun loadLabelIcon(pkg: String): Pair<String, Drawable?> {
        if (pkg == StatsDb.UNKNOWN_PKG) return "未识别来源（系统 DNS）" to null
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString() to packageManager.getApplicationIcon(ai)
        } catch (e: Exception) {
            pkg to null
        }
    }

    private inner class StatAdapter : BaseAdapter() {
        var data: List<AppStat> = emptyList()
        private val cache = HashMap<String, Pair<String, Drawable?>>()

        override fun getCount() = data.size
        override fun getItem(position: Int): AppStat = data[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_stat, parent, false)
            val s = data[position]
            val (label, icon) = cache.getOrPut(s.pkg) { loadLabelIcon(s.pkg) }
            v.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(icon)
            v.findViewById<TextView>(R.id.tvName).text =
                label + if (prefs.isExcluded(s.pkg)) "（已排除）" else ""
            v.findViewById<TextView>(R.id.tvDetail).text =
                getString(R.string.item_detail, s.skip, s.back, s.dns, s.today)
            v.findViewById<TextView>(R.id.tvCount).text = (s.skip + s.back + s.dns).toString()
            return v
        }
    }
}
