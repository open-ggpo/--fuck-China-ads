package com.qingping.clear

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppStat(val pkg: String, val skip: Int, val back: Int, val dns: Int, val today: Int)

/** 按 App、按天记录拦截次数。只用系统自带 SQLite，不需要 Room/kapt。全进程共用一个实例。 */
class StatsDb private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "qingping.db", null, 2) {

    companion object {
        const val TYPE_SKIP = 0   // 自动点击了“跳过”
        const val TYPE_BACK = 1   // 拦截了误触跳转（自动返回）
        const val TYPE_DNS = 2    // VPN 的 DNS 过滤拦下了一个广告域名

        /** DNS 拦截无法确定是哪个 App 发起时使用 */
        const val UNKNOWN_PKG = "_unknown"

        @Volatile
        private var instance: StatsDb? = null

        fun get(context: Context): StatsDb =
            instance ?: synchronized(this) {
                instance ?: StatsDb(context.applicationContext).also { instance = it }
            }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE stats(
                 pkg TEXT NOT NULL,
                 day TEXT NOT NULL,
                 skip_cnt INTEGER NOT NULL DEFAULT 0,
                 back_cnt INTEGER NOT NULL DEFAULT 0,
                 dns_cnt INTEGER NOT NULL DEFAULT 0,
                 PRIMARY KEY(pkg, day))"""
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE stats ADD COLUMN dns_cnt INTEGER NOT NULL DEFAULT 0")
        }
    }

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized
    fun record(pkg: String, type: Int) {
        val col = when (type) {
            TYPE_SKIP -> "skip_cnt"
            TYPE_BACK -> "back_cnt"
            else -> "dns_cnt"
        }
        val day = today()
        val db = writableDatabase
        db.execSQL("INSERT OR IGNORE INTO stats(pkg, day) VALUES(?, ?)", arrayOf<Any>(pkg, day))
        db.execSQL("UPDATE stats SET $col = $col + 1 WHERE pkg = ? AND day = ?", arrayOf<Any>(pkg, day))
    }

    @Synchronized
    fun queryAll(): List<AppStat> {
        val list = ArrayList<AppStat>()
        readableDatabase.rawQuery(
            "SELECT pkg, SUM(skip_cnt), SUM(back_cnt), SUM(dns_cnt), " +
                "SUM(CASE WHEN day = ? THEN skip_cnt + back_cnt + dns_cnt ELSE 0 END) " +
                "FROM stats GROUP BY pkg ORDER BY SUM(skip_cnt + back_cnt + dns_cnt) DESC",
            arrayOf(today())
        ).use { c ->
            while (c.moveToNext()) {
                list.add(AppStat(c.getString(0), c.getInt(1), c.getInt(2), c.getInt(3), c.getInt(4)))
            }
        }
        return list
    }

    @Synchronized
    fun clear() {
        writableDatabase.execSQL("DELETE FROM stats")
    }
}
