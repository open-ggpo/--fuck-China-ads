package com.qingping.clear

import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.system.OsConstants
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * 本地 VPN，只做 DNS 过滤，不转发任何其他流量：
 * - 把系统 DNS 指向一个虚构地址 10.111.222.1，并且只把这一个 /32 地址路由进 VPN，
 *   所以只有 DNS 查询会经过本应用，其他流量照常走原来的网络；
 * - 域名在列表里：直接伪造应答（A 记录 0.0.0.0 / AAAA ::），让广告 SDK 连不上；
 * - 其他域名：用受保护的 socket（protect）转发给原网络的 DNS，再把应答写回。
 * 不具备联网权限，所有数据都只在本机处理。
 */
class QpVpnService : VpnService() {

    companion object {
        @Volatile
        var running = false

        private const val VPN_ADDR = "10.111.222.2"
        private const val DNS_ADDR = "10.111.222.1"
        private val DNS_BYTES = byteArrayOf(10, 111, 222.toByte(), 1)
        private val FALLBACK_DNS = arrayOf("223.5.5.5", "119.29.29.29", "8.8.8.8")
    }

    private class Question(val name: String, val type: Int, val endOffset: Int)

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var pool: ExecutorService? = null
    private lateinit var db: StatsDb
    private lateinit var prefs: Prefs

    @Volatile private var upstreamCache: List<InetAddress> = emptyList()
    @Volatile private var upstreamAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startTunnel()
        return START_STICKY
    }

    @Synchronized
    private fun startTunnel() {
        if (running) return
        db = StatsDb.get(this)
        prefs = Prefs(this)

        val builder = Builder()
            .setSession("清屏 DNS 过滤")
            .addAddress(VPN_ADDR, 32)
            .addDnsServer(DNS_ADDR)
            .addRoute(DNS_ADDR, 32)
            .setBlocking(true)
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)

        val pfd = try {
            builder.establish()
        } catch (e: Exception) {
            null
        }
        if (pfd == null) {
            stopSelf()
            return
        }
        tun = pfd
        running = true
        pool = Executors.newFixedThreadPool(4)
        worker = Thread({
            Blocklist.reload(applicationContext)   // 大列表放到后台线程加载
            loop(pfd)
        }, "qp-vpn").also { it.start() }
    }

    @Synchronized
    private fun stopTunnel() {
        running = false
        pool?.shutdownNow()
        pool = null
        try {
            tun?.close()
        } catch (e: IOException) {
        }
        tun = null
        worker = null
    }

    private fun loop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val n = try {
                input.read(buf)
            } catch (e: IOException) {
                break
            }
            if (n <= 0) continue
            val pkt = buf.copyOf(n)
            try {
                pool?.execute { handlePacket(pkt, output) }
            } catch (e: Exception) {
                break
            }
        }
        if (running) {          // 非主动停止却退出了循环
            stopTunnel()
            stopSelf()
        }
    }

    private fun handlePacket(pkt: ByteArray, out: FileOutputStream) {
        try {
            if (pkt.size < 28) return
            if ((pkt[0].toInt() shr 4) != 4) return                  // 只处理 IPv4
            val ihl = (pkt[0].toInt() and 0x0F) * 4
            if (ihl < 20 || pkt.size < ihl + 8) return
            if ((pkt[9].toInt() and 0xFF) != 17) return              // 只处理 UDP
            if (!pkt.copyOfRange(16, 20).contentEquals(DNS_BYTES)) return
            val srcPort = u16(pkt, ihl)
            if (u16(pkt, ihl + 2) != 53) return
            val udpLen = u16(pkt, ihl + 4)
            val dnsOff = ihl + 8
            val dnsLen = minOf(udpLen - 8, pkt.size - dnsOff)
            if (dnsLen < 12) return

            val dns = pkt.copyOfRange(dnsOff, dnsOff + dnsLen)
            val q = parseQuestion(dns, dnsLen)
            val flags = u16(dns, 2)
            val isQuery = (flags and 0x8000) == 0 && ((flags shr 11) and 0xF) == 0 && u16(dns, 4) == 1

            var pkg: String? = null
            var blocked = false
            if (q != null && isQuery) {
                pkg = attribute(InetAddress.getByAddress(pkt.copyOfRange(12, 16)), srcPort)
                val excluded = pkg != null && prefs.isExcluded(pkg)
                blocked = !excluded && Blocklist.isBlocked(q.name)
                if (q.type == 1 || q.type == 28) {
                    VpnLog.add(VpnLog.Entry(System.currentTimeMillis(), pkg, q.name, blocked))
                }
            }

            val reply: ByteArray? = if (blocked && q != null) {
                if (q.type == 1) db.record(pkg ?: StatsDb.UNKNOWN_PKG, StatsDb.TYPE_DNS)  // 只数 A 记录，避免 A/AAAA 重复计数
                buildBlockedReply(dns, q)
            } else {
                forward(dns, dnsLen)
            }
            if (reply != null) writeReply(out, pkt, ihl, reply)
        } catch (e: Exception) {
            // 单个包出错不影响后续
        }
    }

    /**
     * 判断这条 DNS 查询是谁发的。
     * Android 10+ 优先用 getConnectionOwnerUid；拿不到（或属于系统）时，退回到“当前前台 App”这个近似值，
     * 因为开屏广告的域名请求几乎都发生在 App 刚启动的时候。这是启发式，可能偶尔归错 App。
     */
    private fun attribute(src: InetAddress, srcPort: Int): String? {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val cm = getSystemService(ConnectivityManager::class.java)
                val uid = cm.getConnectionOwnerUid(
                    OsConstants.IPPROTO_UDP,
                    InetSocketAddress(src, srcPort),
                    InetSocketAddress(InetAddress.getByName(DNS_ADDR), 53)
                )
                if (uid >= 10000) {
                    val p = packageManager.getPackagesForUid(uid)?.firstOrNull()
                    if (p != null) return p
                }
            } catch (e: Exception) {
            }
        }
        return SkipAccessibilityService.foregroundPkg
    }

    private fun parseQuestion(dns: ByteArray, len: Int): Question? {
        if (len < 17) return null
        var p = 12
        val sb = StringBuilder()
        while (true) {
            if (p >= len) return null
            val l = dns[p].toInt() and 0xFF
            if (l == 0) {
                p++
                break
            }
            if ((l and 0xC0) != 0) return null            // 问题段里不应出现压缩指针
            if (p + 1 + l > len) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, p + 1, l, Charsets.US_ASCII))
            p += 1 + l
        }
        if (p + 4 > len) return null
        return Question(sb.toString().lowercase(Locale.ROOT), u16(dns, p), p + 4)
    }

    /** 伪造应答：A→0.0.0.0，AAAA→::，其他类型（如 HTTPS）返回“无记录”，让客户端回退到 A 查询 */
    private fun buildBlockedReply(dns: ByteArray, q: Question): ByteArray {
        val rdata: ByteArray? = when (q.type) {
            1 -> ByteArray(4)
            28 -> ByteArray(16)
            else -> null
        }
        val out = ByteArrayOutputStream()
        out.write(dns, 0, q.endOffset)                        // 头部 + 问题段（丢掉 EDNS 等附加段）
        if (rdata != null) {
            out.write(byteArrayOf(0xC0.toByte(), 0x0C))       // 名字：指向偏移 12 的问题名
            out.write(q.type shr 8); out.write(q.type and 0xFF)
            out.write(0); out.write(1)                        // class IN
            out.write(0); out.write(0); out.write(0); out.write(60)   // TTL 60s
            out.write(0); out.write(rdata.size)
            out.write(rdata)
        }
        val r = out.toByteArray()
        val flags = (u16(dns, 2) and 0x7900) or 0x8000 or 0x0080   // 保留 opcode 与 RD，置 QR、RA，RCODE=0
        put16(r, 2, flags)
        put16(r, 6, if (rdata != null) 1 else 0)               // ANCOUNT
        put16(r, 8, 0)
        put16(r, 10, 0)
        return r
    }

    private fun upstreams(): List<InetAddress> {
        val now = SystemClock.elapsedRealtime()
        if (upstreamCache.isNotEmpty() && now - upstreamAt < 20_000) return upstreamCache
        upstreamAt = now
        val list = ArrayList<InetAddress>()
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                cm.getLinkProperties(n)?.dnsServers?.forEach { if (it !in list) list.add(it) }
            }
        } catch (e: Exception) {
        }
        for (f in FALLBACK_DNS) {
            try {
                list.add(InetAddress.getByName(f))
            } catch (e: Exception) {
            }
        }
        upstreamCache = list
        return list
    }

    private fun forward(dns: ByteArray, len: Int): ByteArray? {
        for (server in upstreams()) {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket()
                protect(sock)                                   // 绕过 VPN，直接走底层网络
                sock.soTimeout = 2500
                sock.send(DatagramPacket(dns, len, server, 53))
                val buf = ByteArray(4096)
                val p = DatagramPacket(buf, buf.size)
                sock.receive(p)
                return buf.copyOf(p.length)
            } catch (e: Exception) {
                // 换下一个上游
            } finally {
                sock?.close()
            }
        }
        return null
    }

    /** 把 DNS 应答包装成 IPv4+UDP 包写回 TUN：源/目的地址与端口互换 */
    private fun writeReply(out: FileOutputStream, req: ByteArray, ihl: Int, payload: ByteArray) {
        val udpLen = 8 + payload.size
        val total = 20 + udpLen
        val r = ByteArray(total)
        r[0] = 0x45
        put16(r, 2, total)
        put16(r, 6, 0x4000)                                    // DF
        r[8] = 64
        r[9] = 17
        System.arraycopy(req, 16, r, 12, 4)                    // 源 = 原目的（虚构 DNS）
        System.arraycopy(req, 12, r, 16, 4)                    // 目的 = 原源
        put16(r, 10, checksum(r, 0, 20, 0L))

        System.arraycopy(req, ihl + 2, r, 20, 2)               // 源端口 = 53
        System.arraycopy(req, ihl, r, 22, 2)                   // 目的端口 = 原源端口
        put16(r, 24, udpLen)
        System.arraycopy(payload, 0, r, 28, payload.size)

        var pseudo = 17L + udpLen
        for (i in 12 until 20 step 2) pseudo += u16(r, i)
        var c = checksum(r, 20, udpLen, pseudo)
        if (c == 0) c = 0xFFFF
        put16(r, 26, c)

        synchronized(out) { out.write(r) }
    }

    override fun onRevoke() {
        // 用户在系统里关闭了 VPN，或被其他 VPN 顶掉
        Prefs(this).vpnEnabled = false
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }
}

private fun u16(b: ByteArray, o: Int): Int =
    ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

private fun put16(b: ByteArray, o: Int, v: Int) {
    b[o] = (v shr 8).toByte()
    b[o + 1] = v.toByte()
}

private fun checksum(data: ByteArray, off: Int, len: Int, initial: Long): Int {
    var sum = initial
    var i = off
    val end = off + len
    while (i + 1 < end) {
        sum += u16(data, i)
        i += 2
    }
    if (i < end) sum += (data[i].toInt() and 0xFF) shl 8
    while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
    return (sum.inv() and 0xFFFF).toInt()
}
