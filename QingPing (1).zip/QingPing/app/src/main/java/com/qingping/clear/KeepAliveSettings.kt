package com.qingping.clear

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast

/** 跳转到各类“保活”相关的系统设置页。厂商页面的类名随系统版本会变，找不到时回退到应用详情页。 */
object KeepAliveSettings {

    fun requestIgnoreBattery(a: Activity) {
        val pm = a.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(a.packageName)) {
            Toast.makeText(a, "已在电池优化白名单中", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            a.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${a.packageName}"))
            )
        } catch (e: Exception) {
            try {
                a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                openAppInfo(a)
            }
        }
    }

    private val AUTOSTART_PAGES = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity",
        "com.asus.mobilemanager" to "com.asus.mobilemanager.autostart.AutoStartActivity"
    )

    fun openAutoStart(a: Activity) {
        for ((pkg, cls) in AUTOSTART_PAGES) {
            try {
                a.startActivity(Intent().setComponent(ComponentName(pkg, cls)))
                return
            } catch (e: Exception) {
                // 这台手机没有这个页面，试下一个
            }
        }
        Toast.makeText(
            a, "没找到本机的自启动页面，请在应用详情里手动允许自启动/后台运行，并在最近任务里锁定清屏",
            Toast.LENGTH_LONG
        ).show()
        openAppInfo(a)
    }

    fun openAppInfo(a: Activity) {
        a.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}"))
        )
    }
}
