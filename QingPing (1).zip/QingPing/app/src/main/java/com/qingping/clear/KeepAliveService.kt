package com.qingping.clear

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * 前台服务：用一条常驻通知提高进程优先级，降低被系统/清理工具杀掉的概率；
 * 如果用户开启了“自动重新开启”且已 adb 授权，还会每 30 秒检查并恢复无障碍开关。
 */
class KeepAliveService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val guard = object : Runnable {
        override fun run() {
            if (Prefs(this@KeepAliveService).autoRevive) {
                AccessibilityGuard.tryReEnable(this@KeepAliveService)
            }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("keepalive", "清屏运行状态", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = Notification.Builder(this, "keepalive")
            .setContentTitle("清屏运行中")
            .setContentText("正在守护开屏广告跳过功能")
            .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
        handler.removeCallbacks(guard)
        handler.post(guard)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(guard)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
