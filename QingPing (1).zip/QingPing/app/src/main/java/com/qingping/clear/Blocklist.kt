package com.qingping.clear

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.Locale

/**
 * 广告域名列表 = 内置种子 + 用户导入/点选的自定义屏蔽 − 用户放行。
 * 匹配按“域名后缀”：屏蔽 example.com 会同时屏蔽 a.b.example.com。
 * 放行优先于屏蔽。
 *
 * 内置种子只是起点：是常见广告联盟的域名，没有在真机流量上逐个验证，也不可能覆盖全部。
 * 建议自行导入社区维护的 hosts / 域名列表，并用“最近 DNS 查询”补充。
 */
object Blocklist {

    private const val FILE_BLOCK = "custom_blocklist.txt"
    private const val FILE_ALLOW = "allowlist.txt"

    private val SEED: Set<String> = setOf(
        // Google / AdMob
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "googletagservices.com", "adservice.google.com", "2mdn.net",
        // 海外联盟
        "an.facebook.com", "applovin.com", "applvn.com", "unityads.unity3d.com",
        "vungle.com", "ironsrc.com", "supersonicads.com", "mintegral.com",
        "mtgglobals.com", "inmobi.com", "chartboost.com", "adcolony.com",
        "tapjoy.com", "smaato.net", "mopub.com", "startappservice.com",
        // 腾讯 优量汇 / 广点通
        "gdt.qq.com", "e.qq.com", "gdtimg.com", "ugdtimg.com",
        // 百度联盟
        "mobads.baidu.com", "mobads-logs.baidu.com", "cpro.baidu.com",
        "pos.baidu.com", "eclick.baidu.com",
        // 字节 穿山甲 / Pangle
        "pangolin-sdk-toutiao.com", "pangolin-sdk-toutiao-b.com", "pangleglobal.com",
        "pangle.io", "tobsnssdk.com", "pglstatp-toutiao.com",
        // 快手联盟、Sigmob、阿里妈妈
        "ad.partner.gifshow.com", "adukwai.com", "e.kuaishou.com",
        "sigmob.com", "sigmob.cn", "alimama.com", "tanx.com",
        // 小米系统广告
        "ad.xiaomi.com", "adv.sec.miui.com"
    )

    @Volatile private var blocked: Set<String> = SEED
    @Volatile private var allowed: Set<String> = emptySet()
    @Volatile private var customCount = 0

    private val DOMAIN = Regex("[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+")

    /** 支持 hosts 格式（0.0.0.0 domain）、纯域名、AdGuard 简单规则（||domain^）；# 开头为注释 */
    fun parse(line: String): String? {
        val l = line.substringBefore('#').trim().lowercase(Locale.ROOT)
        if (l.isEmpty()) return null
        val parts = l.split(Regex("\\s+"))
        var d = if (parts.size >= 2 &&
            (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1" || parts[0] == "::" || parts[0] == "::1")
        ) parts[1] else parts[0]
        d = d.removePrefix("||").removePrefix("*.").substringBefore('^').trimEnd('.')
        if (d.all { it.isDigit() || it == '.' }) return null      // 纯 IP
        return if (DOMAIN.matches(d)) d else null
    }

    private fun readFile(ctx: Context, name: String): List<String> {
        val f = File(ctx.filesDir, name)
        return if (f.exists()) f.readLines().mapNotNull { parse(it) } else emptyList()
    }

    private fun writeFile(ctx: Context, name: String, items: Collection<String>) {
        File(ctx.filesDir, name).writeText(items.joinToString("\n"))
    }

    /** 列表可能很大，请在后台线程调用 */
    @Synchronized
    fun reload(ctx: Context) {
        val custom = readFile(ctx, FILE_BLOCK)
        val b = HashSet<String>(SEED)
        b.addAll(custom)
        customCount = custom.size
        blocked = b
        allowed = HashSet(readFile(ctx, FILE_ALLOW))
    }

    fun isBlocked(name: String): Boolean {
        val block = blocked
        val allow = allowed
        var d = name.lowercase(Locale.ROOT).trimEnd('.')
        var hit = false
        while (d.contains('.')) {
            if (d in allow) return false
            if (d in block) hit = true
            d = d.substring(d.indexOf('.') + 1)
        }
        return hit
    }

    @Synchronized
    fun block(ctx: Context, domain: String) {
        val custom = LinkedHashSet(readFile(ctx, FILE_BLOCK))
        custom.add(domain)
        writeFile(ctx, FILE_BLOCK, custom)
        val allow = LinkedHashSet(readFile(ctx, FILE_ALLOW))
        if (allow.remove(domain)) writeFile(ctx, FILE_ALLOW, allow)
        reload(ctx)
    }

    @Synchronized
    fun allow(ctx: Context, domain: String) {
        val allow = LinkedHashSet(readFile(ctx, FILE_ALLOW))
        allow.add(domain)
        writeFile(ctx, FILE_ALLOW, allow)
        reload(ctx)
    }

    /** 从用户选择的文件导入，返回新增条数。仅读本地文件，不需要联网权限。 */
    @Synchronized
    fun importFrom(ctx: Context, uri: Uri): Int {
        val custom = LinkedHashSet(readFile(ctx, FILE_BLOCK))
        var added = 0
        ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
            for (line in lines) {
                val d = parse(line) ?: continue
                if (custom.add(d)) added++
            }
        }
        writeFile(ctx, FILE_BLOCK, custom)
        reload(ctx)
        return added
    }

    @Synchronized
    fun clearCustom(ctx: Context) {
        File(ctx.filesDir, FILE_BLOCK).delete()
        File(ctx.filesDir, FILE_ALLOW).delete()
        reload(ctx)
    }

    fun describe(): String =
        "内置 ${SEED.size} 条 · 自定义屏蔽 $customCount 条 · 放行 ${allowed.size} 条"
}
