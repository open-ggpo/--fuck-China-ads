package com.qingping.clear

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("qingping", Context.MODE_PRIVATE)

    /** 开屏后几秒内被广告跳转到应用商店/浏览器时，自动返回 */
    var redirectBack: Boolean
        get() = sp.getBoolean("redirect_back", true)
        set(v) = sp.edit().putBoolean("redirect_back", v).apply()

    /** 激进模式：跳转到任何（非系统）App 都返回，而不只是应用商店/浏览器 */
    var aggressive: Boolean
        get() = sp.getBoolean("aggressive", false)
        set(v) = sp.edit().putBoolean("aggressive", v).apply()

    /** 常驻通知（前台服务）保活 */
    var keepAlive: Boolean
        get() = sp.getBoolean("keep_alive", true)
        set(v) = sp.edit().putBoolean("keep_alive", v).apply()

    /** 无障碍服务被关掉后自动重新开启（需 adb 授予 WRITE_SECURE_SETTINGS） */
    var autoRevive: Boolean
        get() = sp.getBoolean("auto_revive", false)
        set(v) = sp.edit().putBoolean("auto_revive", v).apply()

    /** 用户希望开启 VPN DNS 过滤（开机后据此决定是否自动拉起；被系统/其他 VPN 撤销时置为 false） */
    var vpnEnabled: Boolean
        get() = sp.getBoolean("vpn_enabled", false)
        set(v) = sp.edit().putBoolean("vpn_enabled", v).apply()

    fun isExcluded(pkg: String): Boolean =
        sp.getStringSet("excluded", null)?.contains(pkg) == true

    fun setExcluded(pkg: String, excluded: Boolean) {
        // getStringSet 返回的集合不能直接修改，必须拷贝
        val set = HashSet<String>(sp.getStringSet("excluded", null) ?: emptySet<String>())
        if (excluded) set.add(pkg) else set.remove(pkg)
        sp.edit().putStringSet("excluded", set).apply()
    }
}
