package com.qingping.clear

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import java.util.ArrayDeque

/**
 * 核心服务。思路：
 * 1. 只监听 TYPE_WINDOW_STATE_CHANGED，判断“哪个 App 刚进入前台”；
 * 2. 进入前台后的 SCAN_WINDOW_MS 内，每 200ms 扫描一次界面，找“跳过”按钮并点击；
 * 3. 若 App 刚进入前台几秒内就直接跳到应用商店/浏览器，自动按一次“返回”。
 * 这是“自动跳过”，不是“阻止广告加载”：广告仍会被加载、短暂显示。
 */
class SkipAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var connected = false

        /** 当前前台 App 的包名（回到桌面/系统界面时为 null），供 VPN 模式给 DNS 请求归属 App 时参考 */
        @Volatile
        var foregroundPkg: String? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: StatsDb
    private lateinit var prefs: Prefs

    private var currentPkg: String? = null
    private var enterAt = 0L
    private var scanDeadline = 0L
    private var lastClickAt = 0L
    private var clickCount = 0
    private var pendingVerify = false

    private var launcherPkgs: Set<String> = emptySet()
    private var imePkgs: Set<String> = emptySet()
    private var setsRefreshedAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        db = StatsDb.get(this)
        prefs = Prefs(this)
        connected = true
        refreshPkgSets(force = true)
        if (prefs.keepAlive) {
            // 后台启动前台服务可能被系统拒绝，失败就算了
            try {
                ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        refreshPkgSets()
        when {
            // 回到桌面 / 下拉通知栏或最近任务 / 打开清屏自己：视为“当前没有被监控的 App”
            pkg == packageName || pkg in launcherPkgs || pkg == "com.android.systemui" ->
                resetForeground()
            // 输入法、权限弹窗等：忽略
            pkg in imePkgs || pkg in Rules.SYSTEM_NEUTRAL -> return
            pkg == currentPkg -> return
            else -> onForegroundChanged(currentPkg, pkg)
        }
    }

    private fun resetForeground() {
        handler.removeCallbacks(poll)
        finishPending(currentPkg)
        currentPkg = null
        foregroundPkg = null
    }

    private fun onForegroundChanged(oldPkg: String?, newPkg: String) {
        val now = SystemClock.uptimeMillis()

        // 误触跳转：老 App 刚进入前台没多久，就直接跳到了商店/浏览器
        var willGoBack = false
        if (oldPkg != null && prefs.redirectBack && !prefs.isExcluded(oldPkg) &&
            now - enterAt <= Rules.REDIRECT_WINDOW_MS && isRedirectTarget(newPkg)
        ) {
            willGoBack = true
            scheduleBack(from = oldPkg, target = newPkg)
        }

        handler.removeCallbacks(poll)
        finishPending(oldPkg)
        currentPkg = newPkg
        foregroundPkg = newPkg
        enterAt = now
        scanDeadline = now + Rules.SCAN_WINDOW_MS
        clickCount = 0
        lastClickAt = 0L
        pendingVerify = false
        if (!willGoBack && !prefs.isExcluded(newPkg)) handler.post(poll)
    }

    private fun isRedirectTarget(pkg: String): Boolean =
        pkg in Rules.REDIRECT_TARGETS ||
            (prefs.aggressive && pkg !in Rules.SYSTEM_NEUTRAL && pkg !in imePkgs)

    private fun scheduleBack(from: String, target: String) {
        handler.postDelayed({
            if (currentPkg == target) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                db.record(from, StatsDb.TYPE_BACK)
                // 有些落地页要按两次才能退回，0.9 秒后若仍在目标 App 再按一次
                handler.postDelayed({
                    if (currentPkg == target) performGlobalAction(GLOBAL_ACTION_BACK)
                }, 900)
            }
        }, 350)
    }

    /** 点击后目标按钮消失（或界面已切走）才算一次成功跳过，避免只“点了”但没生效也计数 */
    private fun finishPending(pkg: String?) {
        if (pendingVerify && pkg != null) db.record(pkg, StatsDb.TYPE_SKIP)
        pendingVerify = false
    }

    private val poll = object : Runnable {
        override fun run() {
            val pkg = currentPkg ?: return
            val now = SystemClock.uptimeMillis()
            if (now > scanDeadline) {
                pendingVerify = false
                return
            }
            val root = rootInActiveWindow
            if (root != null && root.packageName?.toString() == pkg) {
                val target = findSkipNode(root)
                if (target != null) {
                    if (clickCount < Rules.MAX_CLICKS && now - lastClickAt >= 800) {
                        lastClickAt = now
                        clickCount++
                        if (clickNode(target)) pendingVerify = true
                    }
                } else if (pendingVerify) {
                    pendingVerify = false
                    db.record(pkg, StatsDb.TYPE_SKIP)
                }
            }
            handler.postDelayed(this, Rules.POLL_INTERVAL_MS)
        }
    }

    /** 广度优先遍历，限制节点数，避免复杂界面卡顿。API 33+ 的 recycle() 已是空操作，这里不再手动回收。 */
    private fun findSkipNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val dm = resources.displayMetrics
        val area = dm.widthPixels.toLong() * dm.heightPixels
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < Rules.MAX_NODES) {
            val node = queue.poll() ?: break
            visited++
            if (Rules.looksLikeSkip(node, area)) return node
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    /** 先找自己或最近的可点击祖先做 ACTION_CLICK；不行再用手势在按钮中心点一下 */
    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 5) {
            if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun refreshPkgSets(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && setsRefreshedAt != 0L && now - setsRefreshedAt < 10 * 60_000L) return
        setsRefreshedAt = now
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            launcherPkgs = packageManager
                .queryIntentActivities(home, PackageManager.MATCH_DEFAULT_ONLY)
                .map { it.activityInfo.packageName }
                .toSet()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imePkgs = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) {
            // 保持旧值
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        foregroundPkg = null
        handler.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        foregroundPkg = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
