package com.qingping.clear

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/** 匹配规则与各种常量。想适配更多 App，主要改这个文件。 */
object Rules {
    /** App 进入前台后，只在这段时间内扫描“跳过”按钮，降低误点概率 */
    const val SCAN_WINDOW_MS = 6_000L
    const val POLL_INTERVAL_MS = 200L

    /** App 进入前台后，这段时间内直接跳到商店/浏览器才视为“误触跳转” */
    const val REDIRECT_WINDOW_MS = 6_000L

    const val MAX_NODES = 1_500
    const val MAX_CLICKS = 3

    /** 输入法、权限弹窗等：既不算“切换了 App”，也不打断当前判断 */
    val SYSTEM_NEUTRAL = setOf(
        "android",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.settings"
    )

    /** 默认认为“开屏广告误触后常被带去”的目标：应用商店 + 浏览器 */
    val REDIRECT_TARGETS = setOf(
        // 应用商店
        "com.android.vending", "com.huawei.appmarket", "com.hihonor.appmarket",
        "com.xiaomi.market", "com.heytap.market", "com.oppo.market",
        "com.bbk.appstore", "com.vivo.appstore", "com.tencent.android.qqdownloader",
        "com.meizu.mstore", "com.sec.android.app.samsungapps", "com.coolapk.market",
        "com.qihoo.appstore", "com.baidu.appsearch", "com.wandoujia.phoenix2",
        // 浏览器
        "com.android.chrome", "com.android.browser", "com.UCMobile", "com.tencent.mtt",
        "com.quark.browser", "com.baidu.browser.apps", "org.mozilla.firefox",
        "com.huawei.browser", "com.hihonor.baidu.browser", "com.heytap.browser",
        "com.miui.browser", "com.mi.globalbrowser", "com.vivo.browser",
        "com.sec.android.app.sbrowser", "com.microsoft.emmx"
    )

    private val SKIP_TEXT = Regex(
        """\s*(点击)?(\d{1,2}\s*[sS秒]?\s*[|｜丨]?\s*)?(跳过|跳過|skip)(\s*广告|\s*ad)?(\s*[|｜丨]?\s*\d{1,2}\s*[sS秒]?)?\s*""",
        RegexOption.IGNORE_CASE
    )
    private val ID_SKIP = Regex("skip", RegexOption.IGNORE_CASE)
    private val ID_NEGATIVE = Regex("next|prev|forward|backward|rewind|intro|recap|credit", RegexOption.IGNORE_CASE)

    /**
     * 判断一个节点像不像“跳过”按钮：
     * 文字形如 “跳过 / 跳过 3s / 3s | 跳过 / Skip Ad”，或 view id 含 skip；
     * 并且可见、面积小于屏幕的 1/8（排除整屏容器）。
     */
    fun looksLikeSkip(n: AccessibilityNodeInfo, screenArea: Long): Boolean {
        if (!n.isVisibleToUser) return false
        val text = n.text?.toString()
        val desc = n.contentDescription?.toString()
        val byText = (text != null && text.length <= 14 && SKIP_TEXT.matches(text)) ||
            (desc != null && desc.length <= 14 && SKIP_TEXT.matches(desc))
        val id = n.viewIdResourceName
        val byId = id != null && ID_SKIP.containsMatchIn(id) && !ID_NEGATIVE.containsMatchIn(id)
        if (!byText && !byId) return false

        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        return r.width().toLong() * r.height() < screenArea / 8
    }
}
