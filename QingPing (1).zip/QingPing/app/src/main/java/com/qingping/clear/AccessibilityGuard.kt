package com.qingping.clear

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

object AccessibilityGuard {

    private fun component(ctx: Context) =
        ComponentName(ctx, SkipAccessibilityService::class.java)

    /** 系统设置里是否已勾选本服务（不等于服务已连接） */
    fun isEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = component(ctx)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    fun canWriteSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * 仅当用户已用 adb 授予 WRITE_SECURE_SETTINGS 时才有效。
     * 注意：它会让服务“关不掉”（除非先在本应用里关掉自动重开开关），因此默认关闭、由用户主动选择开启。
     */
    fun tryReEnable(ctx: Context): Boolean {
        if (!canWriteSecure(ctx) || isEnabled(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            val list = cur.split(':').filter { it.isNotBlank() }.toMutableList()
            list.add(component(ctx).flattenToString())
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":"))
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Exception) {
            false
        }
    }
}
