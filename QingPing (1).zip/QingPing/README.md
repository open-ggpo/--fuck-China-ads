# 清屏 QingPing

自动点击其他 App 开屏页的“跳过”、拦截误触跳转（自动返回），可选本地 VPN 做 DNS 广告域名过滤，并按 App 统计。

## 获取 APK（三选一）

1. **GitHub Actions（不用装任何东西）**
   把本文件夹上传为一个 GitHub 仓库 → 打开 Actions → “Build APK” → Run workflow
   → 完成后在该次运行页面底部的 Artifacts 下载 `QingPing-debug-apk`，解压得到 `app-debug.apk`。
2. **Android Studio**：打开本文件夹，等待 Gradle 同步，菜单 Build → Build APK(s)。
3. **命令行**：装好 JDK 17 和 Android SDK（platform 34）后执行 `gradle assembleDebug`（Gradle 8.7），
   产物在 `app/build/outputs/apk/debug/app-debug.apk`。

debug 包由 Android 自动签名，可直接侧载安装。

## 使用要点

- 先在系统里开启无障碍服务（Android 13+ 侧载安装需先“允许受限制的设置”）。
- DNS 过滤：只接管 DNS 查询，其他流量不经过 VPN。系统“私人 DNS”请设为关闭或自动；
  不要勾选系统的“阻止没有 VPN 的连接”。想开机常驻，可在系统 VPN 设置里把清屏设为“始终开启”。
- 应用没有 INTERNET 权限，规则列表只能通过“导入文件”添加。
- 许多 App 使用 HTTPDNS / DoH，DNS 过滤对它们无效；DNS 拦截的 App 归属在部分机型上只能按“前台 App”推断。
